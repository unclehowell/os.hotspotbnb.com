WaveOS
======

This repository is the source code for the WaveOS Micro SD Card image downloadable from makeitwave.com. 
The image is itself a modified version of DietPi, which will retrieve all of the files contained within this repository during first boot-up.

The files contained within are primarily shell script files which are designed to autonomous configure and install several locally hosted applications to whichever Single Board Computer the Micro SD Card (containing the WaveOS) has been inserted into. 

Contained within the makeitwave.com GitHub Page repository is a html user interface which is also used in the product. 
It binds these applications together into one stylish, mobile first, dashboard. 

This /docs directory is where the Sphinx Technical Documentation (using a theme provided by Read the Docs) is located.
The methodology to update these Sphinx/ Read the Docs Documents are well documented online.

If you want to manually amend these technical documents published to docs.makeitwave.com, then you simply need to retrieve a local copy of this directory using Git Clone and alter the content within the .rst files contained within. Then cd into the /docs directory and enter the command 'make html'. Providing you have sphinx installed this command will re-publish the .rst files into html files using the Read the Docs these (or whichever theme is specified in the conf.py file. The Push the changes use a program like Git Desktop for Windows.  This being said the Read the Docs website handles all this automatically for us. https://waveos.readthedocs.io/en/latest/

If you find mistakes and/or find something really confusing etc, don't hesitate to submit a support ticket and our team will do our best to remedy the matter. 



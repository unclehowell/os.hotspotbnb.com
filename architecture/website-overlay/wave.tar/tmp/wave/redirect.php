#!/usr/bin/php
<?php

function check_header($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_NOBODY, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_MAXREDIRS, 25);
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	$ret=curl_exec($ch);
	$lastUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
	curl_close($ch);
	preg_match_all( '@^Content-Type:\s+([\w/+]+)(;\s+charset=(\S+))?@im', $ret, $matches );
	if ( isset( $matches[1] ) ) {
		$type=end($matches[1]);
  		// file_put_contents("/tmp/header/".time(),$url . $type);
		if ($type == "text/html") return (true);
	}
	return(false);
}

$temp = array();

// Extend stream timeout to 24 hours
stream_set_timeout(STDIN, 86400);

while ( $input = fgets(STDIN) ) {
  // Split the output (space delimited) from squid into an array.
  $temp = split(' ', $input);

  // Set the URL from squid to a temporary holder.
  file_put_contents("/tmp/output",print_r($temp,true));
  $output = $temp[0] . "\n";

  // Check the URL and rewrite it if it matches foo.example.com
  //if ( strpos($temp[0], "www.dd-wrt.com") !== false ) {
    //$output = "302:http://www.example.com/\n";
  //}
  $client=substr($temp[1],0,strpos($temp[1],"/"));
  $file="/tmp/x/red/". $client;
  clearstatcache(true,$file);
  if (check_header($temp[0])) {
  	if ( strpos($temp[0], "LETMEARGSTOTHEINTERNET") == false ) {
  	if ( strpos($temp[0], "77.232.232.140") == false ) {
		// if ((time() - filemtime ($file)) > 5) {
  		$output = sprintf("302:http://77.232.232.140/wave.php?url=%s\n",$temp[0]);
		// }
  	}
  }
}
  syslog(LOG_WARNING,$client . " " .$temp[0]);
  echo $output;
}
